import cv2
import numpy as np
import HandTrackingModule as htm
import time
import autopy

##########################
wCam, hCam = 640, 480   # Camera width and height
frameR = 100             # Frame Reduction (margin)
smoothening = 7          # Smoothing factor for mouse movement
##########################

pTime = 0
plocX, plocY = 0, 0     # Previous mouse location
clocX, clocY = 0, 0     # Current mouse location
dragging = False         # Flag for drag state

# Set up camera
cap = cv2.VideoCapture(0)
cap.set(3, wCam)
cap.set(4, hCam)

# Initialize HandDetector
detector = htm.handDetector(maxHands=1)

# Get screen dimensions
wScr, hScr = autopy.screen.size()

print("Gesture Controlled Virtual Mouse Started!")
print("Controls:")
print("  Index finger only     -> Move cursor")
print("  All fingers up        -> Left click")
print("  Index + Middle up     -> Right click")
print("  Thumb only up         -> Drag")
print("  Press 'q' to quit")

while True:
    success, img = cap.read()
    if not success:
        print("Failed to read from camera.")
        break

    # Detect hands
    img = detector.findHands(img)
    lmList, bbox = detector.findPosition(img)

    if len(lmList) != 0:
        x1, y1 = lmList[8][1:]    # Index fingertip
        x2, y2 = lmList[12][1:]   # Middle fingertip
        x3, y3 = lmList[4][1:]    # Thumb tip

        fingers = detector.fingersUp()

        # Draw frame boundary rectangle
        cv2.rectangle(img, (frameR, frameR), (wCam - frameR, hCam - frameR), (255, 255, 255), 2)

        # --- 1. Mouse Movement: Only Index Finger raised ---
        if fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
            # Map camera frame coords to screen coords
            x3_mapped = np.interp(x1, (frameR, wCam - frameR), (0, wScr))
            y3_mapped = np.interp(y1, (frameR, hCam - frameR), (0, hScr))

            # Clamp to screen bounds
            x3_mapped = np.clip(x3_mapped, 0, wScr - 1)
            y3_mapped = np.clip(y3_mapped, 0, hScr - 1)

            # Smooth the movement
            clocX = plocX + (x3_mapped - plocX) / smoothening
            clocY = plocY + (y3_mapped - plocY) / smoothening

            autopy.mouse.move(wScr - clocX, clocY)
            cv2.circle(img, (x1, y1), 15, (255, 0, 255), cv2.FILLED)
            plocX, plocY = clocX, clocY
            cv2.putText(img, "Moving", (20, 100), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0), 2)

        # --- 2. Left Click: All Fingers Raised ---
        if fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 1 and fingers[0] == 1:
            autopy.mouse.click(button=autopy.mouse.Button.LEFT)
            cv2.putText(img, "Left Click!", (20, 100), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 255), 2)
            time.sleep(0.2)  # Debounce

        # --- 3. Right Click: Index and Middle Finger raised ---
        elif fingers[1] == 1 and fingers[2] == 1 and fingers[0] == 0 and fingers[3] == 0 and fingers[4] == 0:
            autopy.mouse.click(button=autopy.mouse.Button.RIGHT)
            cv2.putText(img, "Right Click!", (20, 100), cv2.FONT_HERSHEY_PLAIN, 2, (255, 255, 0), 2)
            time.sleep(0.2)  # Debounce

        # --- 4. Dragging: Only Thumb raised ---
        if fingers[0] == 1 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
            if not dragging:
                dragging = True
                plocX = np.clip(np.interp(x3, (frameR, wCam - frameR), (0, wScr)), 0, wScr - 1)
                plocY = np.clip(np.interp(y3, (frameR, hCam - frameR), (0, hScr)), 0, hScr - 1)
                autopy.mouse.toggle(autopy.mouse.Button.LEFT, True)
                autopy.mouse.move(wScr - plocX, plocY)

            x3_mapped = np.clip(np.interp(x3, (frameR, wCam - frameR), (0, wScr)), 0, wScr - 1)
            y3_mapped = np.clip(np.interp(y3, (frameR, hCam - frameR), (0, hScr)), 0, hScr - 1)
            autopy.mouse.move(wScr - x3_mapped, y3_mapped)
            cv2.putText(img, "Dragging", (20, 100), cv2.FONT_HERSHEY_PLAIN, 2, (0, 165, 255), 2)

        # Release drag if thumb is lowered
        if fingers[0] == 0 and dragging:
            dragging = False
            autopy.mouse.toggle(autopy.mouse.Button.LEFT, False)

        # --- 5. Idle State ---
        if all(finger == 0 for finger in fingers):
            cv2.putText(img, "Idle", (wCam // 3, hCam // 2), cv2.FONT_HERSHEY_PLAIN, 3, (0, 0, 255), 3)

    # Display FPS
    cTime = time.time()
    fps = 1 / (cTime - pTime) if (cTime - pTime) > 0 else 0
    pTime = cTime
    cv2.putText(img, f"FPS: {int(fps)}", (20, 50), cv2.FONT_HERSHEY_PLAIN, 2, (255, 0, 0), 2)

    cv2.imshow("Virtual Mouse", img)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("Virtual Mouse stopped.")
