import cvzone
import cv2
from cvzone.HandTrackingModule import HandDetector
import numpy as np
import google.generativeai as genai
from PIL import Image
import streamlit as st
import time

# ─── Streamlit Page Setup ───────────────────────────────────────────────────
st.set_page_config(layout="wide", page_title="Gesture Math Solver")
st.title("✋ Gesture Controlled Math Solver")
st.markdown("Draw math equations using your **index finger** and let AI solve them!")

# Layout
col1, col2 = st.columns([2, 1])

with col1:
    run = st.checkbox('▶ Run Camera', value=True)
    FRAME_WINDOW = st.image([])

with col2:
    st.title("Answer")
    output_text_area = st.subheader("")

st.markdown("""
---
### Gesture Guide:
| Gesture | Action |
|--------|--------|
| ☝️ Index finger only | Draw on canvas |
| 🖐️ All fingers up | Clear canvas |
| 🤟 All except little finger | Submit to AI |
| ✌️ Index + Middle up | Idle (pause drawing) |
""")

# ─── Google Gemini AI Setup ─────────────────────────────────────────────────
# Replace with your actual Google Gemini API key
GEMINI_API_KEY = "YOUR_GEMINI_API_KEY_HERE"
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-1.5-flash")

# ─── Webcam Setup ───────────────────────────────────────────────────────────
cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)

# ─── Hand Detector Setup ────────────────────────────────────────────────────
detector = HandDetector(
    staticMode=False,
    maxHands=1,
    modelComplexity=1,
    detectionCon=0.7,
    minTrackCon=0.5
)


def getHandInfo(img):
    """Detect hand and return finger states and landmarks."""
    hands, img = detector.findHands(img, draw=False, flipType=True)
    if hands:
        hand = hands[0]
        lmList = hand["lmList"]
        fingers = detector.fingersUp(hand)
        return fingers, lmList
    return None, None


def draw(info, prev_pos, canvas):
    """Handle drawing and canvas clearing based on gestures."""
    fingers, lmList = info
    current_pos = None

    if fingers == [0, 1, 0, 0, 0]:
        # Index finger only → Draw
        current_pos = lmList[8][0:2]
        if prev_pos is None:
            prev_pos = current_pos
        cv2.line(canvas, tuple(current_pos), tuple(prev_pos), (255, 0, 255), 10)

    elif fingers == [1, 1, 1, 1, 1]:
        # All fingers up → Clear canvas
        canvas = np.zeros_like(canvas)

    return current_pos, canvas


def sendToAI(model, canvas, fingers):
    """Send canvas drawing to Gemini AI for math solving."""
    if fingers == [1, 1, 1, 1, 0]:
        # All fingers except little finger → Submit
        pil_image = Image.fromarray(canvas)
        try:
            response = model.generate_content([
                "You are a math solver. Look at the handwritten math equation in the image and solve it. "
                "Provide a clear step-by-step solution.",
                pil_image
            ])
            return response.text.strip()
        except Exception as e:
            return f"AI Error: {str(e)}"
    return ""


# ─── Main Loop ──────────────────────────────────────────────────────────────
prev_pos = None
canvas = None
output_text = ""
last_ai_call_time = time.time()
AI_CALL_INTERVAL = 2  # seconds between AI calls

while run:
    success, img = cap.read()
    if not success:
        st.error("Failed to access webcam.")
        break

    img = cv2.flip(img, 1)

    # Initialize canvas on first frame
    if canvas is None:
        canvas = np.zeros_like(img)

    # Get hand gesture info
    info = getHandInfo(img)

    if info[0] is not None:
        fingers, lmList = info

        # Handle drawing
        prev_pos, canvas = draw(info, prev_pos, canvas)

        # Send to AI (rate-limited)
        if time.time() - last_ai_call_time > AI_CALL_INTERVAL:
            result = sendToAI(model, canvas, fingers)
            if result:
                output_text = result
            last_ai_call_time = time.time()

    # Combine webcam feed with canvas overlay
    image_combined = cv2.addWeighted(img, 0.7, canvas, 0.3, 0)
    image_combined_rgb = cv2.cvtColor(image_combined, cv2.COLOR_BGR2RGB)

    # Display in Streamlit
    FRAME_WINDOW.image(image_combined_rgb)

    if output_text:
        output_text_area.text(f"Solution:\n{output_text}")

    cv2.waitKey(1)

cap.release()
